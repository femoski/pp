import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from '../componets/login/login.component';
import { SocketioService } from '../componets/socketio.service';
import { CrashService } from '../service/crash.service';
import { StorageService } from '../service/storage.service';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {

  modalRef:any
  userdata:any
  usersettings:any
  islogin=false
  u_balance:any
  constructor(private modalService: NgbModal,private storage: StorageService,private socketinfo:SocketioService
  ,public crash: CrashService,
  public user: UserService)
  {

  // this.u_balance=user.balance
  // this.islogin=user.islogin_check;  

  }


 
  // sock_action(x:any)
  // {
  //   console.log(x)
  //   if (x.type == 'first') {
  //     if(x.user)
  //     { 
  //     this.u_balance=x.user.balance
  //     this.user.setbalance(x.user.balance)
  //     }
  //   }
  // }

  // ngOnInit()
  // {

  //   var udata=this.storage.getstoredata('user_details');

  //   if(udata)
  //   {
  //      this.userdata = udata
  //      this.islogin=true
  //      console.log(udata)
  //   }
  //   else{
      
  //     this.socketinfo.u_data.subscribe(x => this.update(x))
  //   }

  //   this.socketinfo.sock_msg.subscribe(x => this.sock_action(x))


  // }

  // update(x:any)
  // {
  //   this.userdata=x
  //   console.log(x)
  //   if(x.length!=0)
  //   { 
  //     this.islogin=true
  //   }
  //   else{
  //     this.islogin=false
  //     console.log('got here')
  //   }
   
  // }
  
  open() {
    this.modalRef = this.modalService.open(LoginComponent,{ centered: true , windowClass: 'modal-style-2'});
  }
}
