import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from '../componets/login/login.component';
import { BetHistoryComponent } from '../componets/bet-history/bet-history.component';

import { StorageService } from '../service/storage.service';
import { SocketioService } from '../componets/socketio.service';
import { LimitComponent } from '../componets/limit/limit.component';
@Component({
  selector: 'app-settings-menu',
  templateUrl: './settings-menu.component.html',
  styleUrls: ['./settings-menu.component.scss']
})
export class SettingsMenuComponent {
  modalRef:any
  userdata:any
  usersettings:any
  islogin=false
  constructor(private modalService: NgbModal,private storage: StorageService,private socketinfo:SocketioService )
  {


  }


  ngOnInit()
  {
    this.usersettings=
    {
      animation:true,
      music:true,
       sound:true
    }
    var udata=this.storage.getstoredata('user_details');
    var u_settings=this.storage.getstoredata('user_settings');

    if(u_settings)
    {
      this.usersettings=u_settings;
    }

    if(udata)
    {
       this.userdata= udata
       this.islogin=true
    }
    else{
      
      this.socketinfo.u_data.subscribe(x => this.update(x))
      this.userdata ={
        name:'demo'
      }
    }
  
  }

  update(x:any)
  {
    this.userdata=x
    if(x.length!=0)
    { 
      console.log(x)
      this.islogin=true
    }
    else
    {
      this.islogin=false

    }
   
  }
  
  open(lesson: any) {
    this.modalRef = this.modalService.open(LoginComponent,{ centered: true , windowClass: 'modal-style-2'});
  }


  bet_history(lesson: any) {
    this.modalRef = this.modalService.open(BetHistoryComponent,{ centered: true , windowClass: 'modal-style-2'});
  }

  game_limit() {
    this.modalRef = this.modalService.open(LimitComponent,{ centered: true , windowClass: 'modal-style-2'});
  }

  user_settings(type:any){
 console.log('it offf')
    if(type=="animation")
    {
      this.usersettings.animation =  !this.usersettings.animation
    }
    if(type=="music")
    {
      this.usersettings.music =  !this.usersettings.music
    }
     if(type=="sound")
    {
      this.usersettings.sound =  !this.usersettings.sound
    }
    this.storage.storearray('user_settings', this.usersettings)
this.socketinfo.update_settings(this.usersettings)
  }

  logout()
  {
this.socketinfo.logout_user('');
  }
}
