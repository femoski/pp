import { Injectable, Input } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { SocketioService } from '../componets/socketio.service';
import { UserService } from './user.service';
import { StorageService } from './storage.service';

@Injectable({
  providedIn: 'root'
})
export class CrashService {
  crash_history_list=new Array
  bet_list_players:any
  bet_list = new Array;
  flew_away=false;
  refreshIntervalId:any;
  oddcounter:any;

  // BUTTON CONTROL
  auto_cashout_value_1 ='1.01';
  awaiting = true
  stake_1 :any ="10.00";
  stake_2 :any ="10.00";
  btn_stage  = 'place_bet_stage'
  btn_stage_1  = 'place_bet_stage'
  cashout_amt_1  = '0.00'
  cashout_amt_2  = '0.00'
  autobet_1 = false
  auto_cashout_1 = false
  next_round_list  = new Array


  // PLAYBOARD MUSIC
  bgaudio = new Audio();
  user_settings:any

  crash_settings = {
    start_time: new Date().getTime(),
    current_progress_time: 0,
    difference_time: 0,
    stage: 'connecting'
  }
  
  
  constructor(private socketservice: SocketioService,private toastr: ToastrService,private user: UserService,private storage: StorageService) { 

    

    this.socketservice.sock_msg.subscribe(m => {
    if (m.type == 'first') {
  
 
      this.crash_history_list=m.crash.history;
      m.crash.bets_all.forEach((crash:any,i:any) =>{
      var list ={
                id:  m.crash.bets_all[i].id,
                amount:  m.crash.bets_all[i].amount,
                name: m.crash.bets_all[i].user.name,
                avatar:  m.crash.bets_all[i].user.avatar
                };
    
      this.bet_list.push(list)
                });

      this.bet_list_players = this.bet_list.sort((a:any, b:any) => a.amount - b.amount)

          setTimeout(() => {
            m.crash.bets_win.forEach((crash:any,i:any) =>{
              this.socketservice.crashGame_editBet(crash)
                      });
            }, 100);
          
      }

    // if(m.type=="balance")
    //   {
    //   this.animateValue(m.balance);
    //   this.user.setbalance(m.balance)
    //   }


    if(m.command=="crashed")
      {

        // if(this.user_settings.sound)
        // {
        //     this.playAudio()
        // }

       var crashed = m.number/100
       this.crash_history_list.push(crashed)

       this.crash_settings.stage = 'crashed'
       clearInterval(this.refreshIntervalId);
       this.oddcounter=((m.number)/100).toFixed(2)
       this.flew_away=true


       if(this.btn_stage=='cashout_bet_stage')
       {
         this.btn_stage  = 'place_bet_stage'
         
       }
       if(this.btn_stage_1=='cashout_bet_stage')
       {
         this.btn_stage_1  = 'place_bet_stage'
         if(this.autobet_1)
         {
           this.place_bet('btn_1')
         }
       }
 

      }

    if(m.command=="cashed_out")
      {
      var cashohtml= `<div class="d-flex">
      <div class="multiplier ">
        <div class="label"> You have cashed out! </div>
        <div class="value"> `+(m.point/100).toFixed(2)+`x </div>
      </div>
      <div class="win celebrated">
        <div class="label no-wrap ">
          <span>Won</span>
          <span class="currency">, NGN</span>
        </div>
        <div class="value">
          <span class="">`+(m.amount).toFixed(2)+`</span>
        </div>
      </div>
    </div>`

      this.toastr.success(cashohtml,'', {
        timeOut: 7000,
        toastClass:'alert-win'
      });
      this.playAudio();
            if(m.btn=='btn_2')
            {
              this.btn_stage  = 'place_bet_stage' 
            }

            if(m.btn=='btn_1')
            {
              this.btn_stage_1  = 'place_bet_stage'

              if(this.autobet_1)
              {
                this.place_bet(m.btn)
              }
            }
      }

    if(m.command=='cashout')
      {

              if(m.btn=='btn_1')
              {
              this.cashout_amt_1 = m.amount.toFixed(2)
              this.btn_stage_1  = 'cashout_bet_stage'
              }

              if(m.btn=='btn_2')
              {
              this.cashout_amt_2 = m.amount.toFixed(2)
              this.btn_stage  = 'cashout_bet_stage'
              }

      }

    if(m.type=='crash' && m.command=='started')
      {  
        this.awaiting =true
        this.flew_away=false
        this.crash_settings.stage = 'progress'
        this.crash_settings.start_time = new Date().getTime();  
        this.crash_settings.difference_time = m.difference
        this.refreshIntervalId = setInterval(() => {
          var cir_time = this.getTime();
          this.oddcounter =this.calcPayout(cir_time).toFixed(2)
        }, 0.1);
      }

    if(m.type=='crash' && m.command=='starting')
      { 
        this.crash_settings.stage = 'starting'
        this.awaiting =false
      }
    
    if(m.command=='get_bet_list')
      {
            this.next_round_list.forEach((crash:any,i:any) =>{
              var   sock_data = {
              'type': 'crash',
              'command': 'bet',
              'amount': crash.amount,
              'auto': crash.auto_cashout,
              'btn': crash.button
                }
            this.socketservice.send_sock_data(sock_data)
              delete this.next_round_list[i];
            });         
            this.next_round_list=[];
      }

    if(m.command=='bet')
      {
           var new_bet = {
            id: m.bet.id,
            amount: m.bet.amount,
            name: m.bet.user.name,
            avatar: m.bet.user.avatar
            };
            
        this.bet_list.push(new_bet)
        this.bet_list_players = this.bet_list.sort((a:any, b:any) => a.amount - b.amount)
  
      }
  
    if(m.command == 'reset') {
        this.bet_list=[];
        this.bet_list_players = this.bet_list=[]
      }

    if(m.type=='error')
    {
      if(m.e_type=="balance")
      {
        if(m.btn=="btn_2")
        {
                  this.btn_stage  = 'place_bet_stage'

        }
        else{
                 this.btn_stage_1  = 'place_bet_stage'

        }
      }
      this.toastr.error(m.error,'', {
        timeOut: 7000,
        //toastClass:'alert-win'
      });
      }

    }) 




    this.bgaudio.src = "./assets/audio/bg_music.mp3";
    this.bgaudio.loop=true;
    this.bgaudio.volume=0.5
    this.bgaudio.load();

    var u_settings=this.storage.getstoredata('user_settings');

    if(u_settings && u_settings.music)
    {
      setTimeout(() => {
        this.bgaudio.play();
      }, 3000);
      
    }
this.user_settings=u_settings;
    this.socketservice.u_settings.subscribe(x => {

      this.user_settings=x
      if(this.user_settings.music)
      {
        this.bgaudio.play();
      }
      else
      {
        this.bgaudio.pause();
      }  
    })

  }

 



  place_bet(button:any)
{
  let pusheditems={}
  if(button=='btn_2')
  {
    
    var autocash=0
    if(this.auto_cashout_1 && button=="btn_1")
    {
       autocash = parseFloat(this.auto_cashout_value_1)
    }

   pusheditems ={
  amount:this.stake_2,
  auto_cashout:autocash,
  button:button
 }
 this.btn_stage='cancel_bet_stage'
}
 else{
  var autocash=0
  if(this.auto_cashout_1 && button=="btn_1")
  {
     autocash = parseFloat(this.auto_cashout_value_1)
  }
  pusheditems ={
    amount:this.stake_1,
    auto_cashout:autocash*100,
    button:button
   }
   this.btn_stage_1='cancel_bet_stage'
 }

this.next_round_list.push(pusheditems);

console.log(this.next_round_list)
}

cancel_stake(button:any){

  this.RemoveElementFromArray(button);
  
  if(button=='btn_2')
  {
    this.btn_stage='place_bet_stage'
    
  }
  if(button=='btn_1')
  {
    this.btn_stage_1='place_bet_stage'
    this.autobet_1=false
  }
  
  }

RemoveElementFromArray(element: any) {
this.next_round_list.forEach((value:any,index:any)=>{
    if(value.button==element) this.next_round_list.splice(index,1);
});
}

  
check_autocashout(value:any,type:any)
{

  if(type='btn_1')
  {
    this.auto_cashout_value_1=(value*1).toFixed(2)

    if(value<1.01)
      {
        this.auto_cashout_value_1='1.01'
      }

       if(value>100)
      {
        this.auto_cashout_value_1='100.00'
      }
  }
}

  get crash_history()
  {
   return this.crash_history_list
  }

  get player_list()
  {
   return this.bet_list_players
  }

  get crash_engine()
  {
   return this.crash_settings
  }
  get payout_counter()
  {
   return this.oddcounter
  }
  get is_flew_away()
  {
   return this.flew_away
  }






  playAudio(){
    let audio = new Audio();
    audio.src = "./assets/audio/cashout.wav";
    audio.load();
    audio.play();
  }
  
    calcPayout(ms:any)
    {
    var gamePayout = Math.floor(100 * this.growthFunc(ms)) / 100;
    return gamePayout;
    }
  
   growthFunc(ms:any)
   {
    var r = 0.00006;
    return Math.pow(Math.E, r * ms);
   }
  
  getTime()
  {
    if(this.crash_settings.stage == 'progress')
      {
      var time = new Date().getTime() - this.crash_settings.start_time + this.crash_settings.difference_time;
      this.crash_settings.current_progress_time = time;
      return time;
      }
    if(this.crash_settings.stage == 'crashed') return this.crash_settings.current_progress_time;
    return 0;
  }

}
