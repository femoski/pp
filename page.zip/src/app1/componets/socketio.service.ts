import { Injectable } from '@angular/core';
import { io } from 'socket.io-client';
import { environment } from 'src/environments/environment';
import * as $ from "jquery";
import { BehaviorSubject } from 'rxjs';
import { StorageService } from '../service/storage.service';
@Injectable({
  providedIn: 'root'
})
export class SocketioService {
  private sock_msgg = new BehaviorSubject<any>([])
  public sock_msg = this.sock_msgg.asObservable()
  public u_data = new BehaviorSubject<Array<any>>([]);
  public u_settings = new BehaviorSubject<Array<any>>([]);


  socket:any;
  
  userdata = {
    session_id: 'Demo'
  }
  constructor(private storage: StorageService) {
      var udata=this.storage.getstoredata('user_details');
      if(udata)
      {
        this.userdata= udata
      }
   }
  
   update_settings(settings:any){
    this.u_settings.next(settings);
  }


  send_sock_data(request:any){
    const ENCODING = 'utf-16le';
    let  str = JSON.stringify(request);
    var data = new TextEncoder().encode(str)
    this.socket.emit('request',{data});
  }


  send_login_request(user:any){
    var sec= {
      session: user.session_id,
      channel: 'en'
    }
    this.socket.emit('join', sec);
    this.u_data.next(user)
  }

  logout_user(user:any){
    localStorage.removeItem('user_details');
    this.u_data.next(user)
  }

  setupSocketConnection() {
    this.socket = io(environment.SOCKET_ENDPOINT, {
      auth: {
        token: "abc"
      }
    });

    // console.log(this.socket)
    var sec= {
      session: this.userdata.session_id,
      channel: 'en'
    }
    this.socket.emit('join', sec);
    const ENCODING = 'utf-16le';

    this.socket.on('b_message', (data: any) => {
      let str = new TextDecoder(ENCODING).decode(data.data),
      json = JSON.parse(str);
      this.onMessageSocket(json);
    });
    this.socket.on('message', (data: string) => {
      this.onMessageSocket(data);
    });

  }
  
  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
    }
  }



  onMessageSocket(m:any)
  {
 
    this.sock_msgg.next(m);


    if(m.command == 'bet_win') {
   this.crashGame_editBet(m.bet)
  }

  }
  




   crashGame_addHistory(crash:any, isInitial = false){
    // var class_pick = (crash <= 1.79) ? 'pick-number-low' : (crash >= 2.00) ? 'pick-number-high' : 'pick-number-medium';
    let c = this.getCrashColor(crash);
 var div = `<div class="payout">
  <div class="bubble_animate multiplier_animate"><div class="multiplier_bubble" style="background:` + c.color + `">`+ this.roundedToFixed(crash, 2).toFixed(2) + `x</div>`

var div2=`<div class="payouts">
<div class="payout">
  <div>
    <div class="bubble-multiplier font-weight-bold" style="padding: 2px 11px; border-radius: 11px; color:` + c.color + `;" > `+ this.roundedToFixed(crash, 2).toFixed(2) + `x </div>
  </div>
</div>
</div>`
    $('.crash_history').prepend(div);
  //  while($('.crash_history').length > 20) $('.crash_history').last().remove();

    $('.crash_history_dropdown').prepend(div2);
  
    //while($('.crash_history_dropdown').length > 20) $('.crash_history_dropdown').last().remove();
  }


  
  
  getCrashColor(val:any) {

    const CRASH_VAL_COLORS = [
      {min: 1.00, max: 2.00, bg: '#34b4ff', color: '#3e5bc2'},
      {min: 2.01, max: 10.00, bg: '#f70707', color: '#753ec2'},
      {min: 10.01, max: 9999999, bg: '#fff200', color: '#c017b4'},
    ];
    for(let i in CRASH_VAL_COLORS) {
      let c = CRASH_VAL_COLORS[i];
  
      if(val >= c.min && val <= c.max) {
        return c;
      }
    }
  
    return CRASH_VAL_COLORS[0];
  }


   crashGame_editBet(bet:any){

    //alert(bet.id)
    let c = this.getCrashColor(bet.cashout);
    var multiplyer=`<div>
    <div class="bubble_animate multiplier_animate"><div class="multiplier_bubble" style="background:` + c.color + `">`+ this.roundedToFixed(bet.cashout, 2).toFixed(2) + `x</div>
    </div>`
    $('#' + bet.id + ' .multiplier-block').html(multiplyer);
    $('#' + bet.id + ' .cash-out').text((bet.total_win*1).toFixed(2));
    $('#' + bet.id).addClass('celebrated');  
  }

  
   roundedToFixed(number:any, decimals:any){
    number = Number((parseFloat(number).toFixed(5)));
    
    var number_string = number.toString();
    var decimals_string = 0;
    
    if(number_string.split('.')[1] !== undefined) decimals_string = number_string.split('.')[1].length;
    
    while(decimals_string - decimals > 0) {
      number_string = number_string.slice(0, -1);
      
      decimals_string --;
    }
    
    return Number(number_string);
  }
  
}