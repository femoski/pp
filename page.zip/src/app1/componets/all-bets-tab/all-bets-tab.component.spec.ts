import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllBetsTabComponent } from './all-bets-tab.component';

describe('AllBetsTabComponent', () => {
  let component: AllBetsTabComponent;
  let fixture: ComponentFixture<AllBetsTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllBetsTabComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AllBetsTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
