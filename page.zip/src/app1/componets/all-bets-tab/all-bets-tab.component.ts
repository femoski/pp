<<<<<<< HEAD
import { Component } from "@angular/core";
import { TableVirtualScrollDataSource } from "ng-table-virtual-scroll";
import { SocketioService } from "../socketio.service";
import { isEmptyObject } from "jquery";
const DATA = Array.from({ length: 1000 }, (v, i) => ({
=======
import { Component } from '@angular/core';
import { TableVirtualScrollDataSource } from 'ng-table-virtual-scroll';
import { SocketioService } from '../socketio.service';
import { isEmptyObject } from 'jquery';
import { CrashService } from 'src/app/service/crash.service';
const DATA = Array.from({length: 1000}, (v, i) => ({
>>>>>>> caef61b2c500a97e530e80417f0141557e9daf4f
  id: i + 1,
  name: `Element #${i + 1}`,
}));

@Component({
  selector: "app-all-bets-tab",
  templateUrl: "./all-bets-tab.component.html",
  styleUrls: ["./all-bets-tab.component.scss"],
})
export class AllBetsTabComponent {
<<<<<<< HEAD
  bet_list_players: any;
  bet_list = new Array();

  constructor(private data: SocketioService) {}

  ngOnInit() {
    this.data.sock_msg.subscribe((m) => {
      if (m.type == "first") {
        m.crash.bets_all.forEach((crash: any, i: any) => {
          var list = {
            id: m.crash.bets_all[i].id,
            amount: m.crash.bets_all[i].amount,
            name: m.crash.bets_all[i].user.name,
            avatar: m.crash.bets_all[i].user.avatar,
          };

          this.bet_list.push(list);
        });
        this.bet_list_players = this.bet_list.sort(
          (a: any, b: any) => a.amount - b.amount
        );
        console.log(this.bet_list_players);

        setTimeout(() => {
          m.crash.bets_win.forEach((crash: any, i: any) => {
            this.data.crashGame_editBet(crash);
            console.log(crash);
          });
        }, 100);
      }

      if (m.command == "bet") {
        var new_bet = {
          id: m.bet.id,
          amount: m.bet.amount,
          name: m.bet.user.name,
          avatar: m.bet.user.avatar,
        };

        this.bet_list.push(new_bet);
        this.bet_list_players = this.bet_list.sort(
          (a: any, b: any) => a.amount - b.amount
        );
      }

      if (m.command == "reset") {
        this.bet_list = [];
        this.bet_list_players = this.bet_list = [];
      }
    });
  }
  displayedColumns = ["id", "name"];

  dataSource = new TableVirtualScrollDataSource(DATA);

  items = Array.from({ length: 100000 }).map((_, i) => `Item #${i}`);

  // sortBy(prop: string) {
  //   this.bet_list_players = this.bet_list_players.sort((a:any, b:any) => a.amount - b.amount)
  // }
=======

  constructor(private data: SocketioService,public crash: CrashService)
{

}
  items = Array.from({length: 100000}).map((_, i) => `Item #${i}`);

  sortBy(prop: string) {
    // this.bet_list_players = this.bet_list_players.sort((a:any, b:any) => a.amount - b.amount)
  }
>>>>>>> caef61b2c500a97e530e80417f0141557e9daf4f
}
