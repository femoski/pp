import { Component, ElementRef, ViewChild } from '@angular/core';
import { SocketioService } from '../socketio.service';
import { CrashService } from 'src/app/service/crash.service';

@Component({
  selector: 'app-bet-control',
  templateUrl: './bet-control.component.html',
  styleUrls: ['./bet-control.component.scss']
})
export class BetControlComponent {

  stake_button_2:boolean = true;
value1: any;

  constructor(private data: SocketioService,public crash: CrashService)
{
}


cashout_bet(button:any)
{

  var cashout_data ={
    'type': 'crash',
    'command': 'cashout',
    'btn': button
 }
 this.data.send_sock_data(cashout_data)

}


plus(val: any , type: any) {
  if(type=='btn_1')
  {
    var value=val*1+30;
    this.crash.stake_1 =value.toFixed(2);
    console.log(this.data.roundedToFixed(value,2).toFixed(2))
    if(this.crash.stake_1>5000)
    {
      this.crash.stake_1="5000.00"
    }
  }


  if(type=='btn_2')
  {
    var value=val*1+30;
    this.crash.stake_2 =value.toFixed(2);
    if(this.crash.stake_2>5000)
    {
      this.crash.stake_2="5000.00"
    }
  }
   
  }


  minus(val: any , type: any) {

    if(type=='btn_1')
    {
      var value=val*1-30;
      this.crash.stake_1 =value.toFixed(2);
      if(this.crash.stake_1<10)
      {
        this.crash.stake_1="10.00"
      }
    }
     
    if(type=='btn_2')
    {
      var value=val*1-30;
      this.crash.stake_2 =value.toFixed(2);
      if(this.crash.stake_2<10)
      {
        this.crash.stake_2="10.00"
      }
    }
    }


 

inputchange(value:any,type:any)
{

  if(type='btn_1')
  {
 
    this.crash.stake_1=(value*1).toFixed(2)

    if(this.crash.stake_1<10)
      {
        this.crash.stake_1="10.00"
      }
  }
}


autobet_control(button:any)
{
  this.crash.autobet_1=!this.crash.autobet_1
  if(this.crash.autobet_1)
  {
    this.crash.place_bet('btn_1');
  }
  else
  {
    this.crash.cancel_stake('btn_1');

  }
}

ngOnDestroy()
{
  this.crash.autobet_1=false
  this.crash.auto_cashout_1=false
  console.log('left page')
}

}
