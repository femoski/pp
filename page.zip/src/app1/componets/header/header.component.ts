import { Component } from '@angular/core';
import { SocketioService } from '../socketio.service';
import { Location } from "@angular/common";
import { UserService } from 'src/app/service/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
balance = 0.0
  constructor(private location: Location,public user: UserService)
  {
     
  }



goBack(): void {
  this.location.back();
}
}
