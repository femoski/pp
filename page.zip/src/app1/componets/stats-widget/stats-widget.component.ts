import { Component } from '@angular/core';
import { CrashService } from 'src/app/service/crash.service';
import { SocketioService } from '../socketio.service';

@Component({
  selector: 'app-stats-widget',
  templateUrl: './stats-widget.component.html',
  styleUrls: ['./stats-widget.component.scss']
})
export class StatsWidgetComponent {
  
  crash_history_list=new Array;
  crash_history_drop=new Array;

constructor(private data: SocketioService,public crash: CrashService)
{
    
}

ngOnInit()
{ 
  // this.data.sock_msg.subscribe(m => {
  //   if (m.type == 'first') {
  //     this.crash_history_list=m.crash.history;
  //     this.crash_history_drop=m.crash.history;
  //   }
  // } )

}



check(aa:any)
{
  

 // this.history = this.history.sort((a:any, b:any) => a - b)
  
}

getCrashColor(val:any) {

  const CRASH_VAL_COLORS = [
    {min: 1.00, max: 1.99, bg: '#34b4ff', color: '#34b4ff'},
    {min: 2.01, max: 10.00, bg: '#f70707', color: '#913ef8'},
    {min: 10.01, max: 9999999, bg: '#fff200', color: '#c017b4'},
  ];
  for(let i in CRASH_VAL_COLORS) {
    let c = CRASH_VAL_COLORS[i];

    if(val >= c.min && val <= c.max) {
      return c.color;
    }
  }

  return CRASH_VAL_COLORS[0];
}

}
