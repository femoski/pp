import { Component } from '@angular/core';
import { SocketioService } from '../socketio.service';
import { StorageService } from 'src/app/service/storage.service';
import { CrashService } from 'src/app/service/crash.service';

@Component({
  selector: 'app-play-board',
  templateUrl: './play-board.component.html',
  styleUrls: ['./play-board.component.scss']
})
export class PlayBoardComponent {
  refreshIntervalId:any;
  bgaudio = new Audio();
  user_settings:any
   crash_settings = {
    start_time: new Date().getTime(),
    current_progress_time: 0,
    difference_time: 0,
    stage: 'starting'
  }
  


  constructor(private data: SocketioService,private storage: StorageService,public crash: CrashService)
  {
     
  }
  
  ngOnInit() {

     
    
    
    
   
  }

  

  callMethod(){
    console.log('Call Function Every Five Seconds.', new Date());
  }

  playAudio(){
    let audio = new Audio();
    audio.src = "../assets/audio/fly_away.mp3";
    audio.load();
    audio.volume=0.9
    audio.play();
  }

  playbgAudio(){

 
    this.bgaudio.play();
  }
  
}
