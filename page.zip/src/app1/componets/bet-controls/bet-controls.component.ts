import { Component } from '@angular/core';

@Component({
  selector: 'app-bet-controls',
  templateUrl: './bet-controls.component.html',
  styleUrls: ['./bet-controls.component.scss']
})
export class BetControlsComponent {

}
