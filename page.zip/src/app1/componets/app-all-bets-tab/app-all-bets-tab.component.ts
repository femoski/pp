import { Component } from '@angular/core';

@Component({
  selector: 'app-app-all-bets-tab',
  templateUrl: './app-all-bets-tab.component.html',
  styleUrls: ['./app-all-bets-tab.component.scss']
})
export class AppAllBetsTabComponent {

}
