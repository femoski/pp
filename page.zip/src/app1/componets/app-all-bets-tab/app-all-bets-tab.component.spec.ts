import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppAllBetsTabComponent } from './app-all-bets-tab.component';

describe('AppAllBetsTabComponent', () => {
  let component: AppAllBetsTabComponent;
  let fixture: ComponentFixture<AppAllBetsTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppAllBetsTabComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AppAllBetsTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
