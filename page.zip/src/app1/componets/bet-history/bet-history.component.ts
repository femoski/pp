import { Component } from '@angular/core';
import { ApiService } from 'src/app/service/api.service';
import { StorageService } from 'src/app/service/storage.service';
import { SocketioService } from '../socketio.service';

@Component({
  selector: 'app-bet-history',
  templateUrl: './bet-history.component.html',
  styleUrls: ['./bet-history.component.scss']
})
export class BetHistoryComponent {
  bet_list_players:any
  entryData:EntryData;

  
  ngOnInit()
  {

    var param =''
    this.api.get('getHistory?game=crash').subscribe((data: any) => {
     this.bet_list_players=data.history;
      
   }, error => {
      console.log(error);
    });


  }
  
  constructor(private api: ApiService, private storage: StorageService, private sockdata: SocketioService
    )
  {
    this.entryData=new EntryData()
  }
 

  getCrashColor(val:any) {

    const CRASH_VAL_COLORS = [
      {min: 1.00, max: 1.99, bg: '#34b4ff', color: '#34b4ff'},
      {min: 2.01, max: 10.00, bg: '#f70707', color: '#913ef8'},
      {min: 10.01, max: 9999999, bg: '#fff200', color: '#c017b4'},
    ];
    for(let i in CRASH_VAL_COLORS) {
      let c = CRASH_VAL_COLORS[i];
  
      if(val >= c.min && val <= c.max) {
        return c.color;
      }
    }
  
    return CRASH_VAL_COLORS[0];
  }
}

export class EntryData{
        section:string="";
        name:string="";
        reprhrase:string="";

}
    