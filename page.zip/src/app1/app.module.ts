import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SettingsMenuComponent } from './settings-menu/settings-menu.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BetsWidgetComponent } from './bets-widget/bets-widget.component';
import { FooterComponent } from './componets/footer/footer.component';
import { StatsWidgetComponent } from './componets/stats-widget/stats-widget.component';
import { PlayBoardComponent } from './componets/play-board/play-board.component';
import { BetControlsComponent } from './componets/bet-controls/bet-controls.component';
import { AppAllBetsTabComponent } from './componets/app-all-bets-tab/app-all-bets-tab.component';
import { AllBetsTabComponent } from './componets/all-bets-tab/all-bets-tab.component';
import { BetControlComponent } from './componets/bet-control/bet-control.component';
import {ScrollingModule} from '@angular/cdk/scrolling'
import { SocketioService } from './componets/socketio.service';
import { HeaderComponent } from './componets/header/header.component';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './componets/login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { CrashComponent } from './crash/crash.component';
import { BetHistoryComponent } from './componets/bet-history/bet-history.component';
import { LimitComponent } from './componets/limit/limit.component';
<<<<<<< HEAD
import { KeyboardComponent } from './keyboard/keyboard.component';
import { KeyboardService } from './keyboard.service';
import { OskInputDirective } from './osk-input.directive';
import { KeyboardKeyDirective } from './keyboard-key.directive';
=======
import { PathLocationStrategy, LocationStrategy } from '@angular/common';
import { HomeComponent } from './home/home.component';
import { NumpadComponent } from './componets/numpad/numpad.component';


>>>>>>> caef61b2c500a97e530e80417f0141557e9daf4f
@NgModule({
  declarations: [
    AppComponent,
    SettingsMenuComponent,
    BetsWidgetComponent,
    FooterComponent,
    StatsWidgetComponent,
    PlayBoardComponent,
    BetControlsComponent,
    AppAllBetsTabComponent,
    AllBetsTabComponent,
    BetControlComponent,
    HeaderComponent,
    LoginComponent,
    CrashComponent,
    BetHistoryComponent,
    LimitComponent,
<<<<<<< HEAD
    KeyboardComponent, OskInputDirective, KeyboardKeyDirective 
=======
    HomeComponent,
    NumpadComponent,
>>>>>>> caef61b2c500a97e530e80417f0141557e9daf4f
  ],
  imports: [
    BrowserModule,
    NgbModule,
    ScrollingModule,
    BrowserAnimationsModule,
    FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        
    ToastrModule.forRoot({
      positionClass :'toast-top-center',
      // closeButton: true,
      enableHtml:true,
    }),
    AppRoutingModule
  ],
<<<<<<< HEAD
  providers: [SocketioService,KeyboardService],
=======
  providers: [SocketioService,{provide: LocationStrategy, useClass: PathLocationStrategy}],
>>>>>>> caef61b2c500a97e530e80417f0141557e9daf4f
  bootstrap: [AppComponent]
})
export class AppModule { }
