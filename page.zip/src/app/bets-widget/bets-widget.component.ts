import { Component } from '@angular/core';

@Component({
  selector: 'app-bets-widget',
  templateUrl: './bets-widget.component.html',
  styleUrls: ['./bets-widget.component.scss']
})
export class BetsWidgetComponent {

}
