import { Component } from '@angular/core';
import { SocketioService } from '../socketio.service';
import { StorageService } from 'src/app/service/storage.service';

@Component({
  selector: 'app-play-board',
  templateUrl: './play-board.component.html',
  styleUrls: ['./play-board.component.scss']
})
export class PlayBoardComponent {
  refreshIntervalId:any;
  bgaudio = new Audio();
  oddcounter='Connecting';
  flew_away:boolean=false
  user_settings:any
   crash_settings = {
    start_time: new Date().getTime(),
    current_progress_time: 0,
    difference_time: 0,
    stage: 'starting'
  }
  


  constructor(private data: SocketioService,private storage: StorageService)
  {
     
  }
  
  ngOnInit() {

    this.bgaudio.src = "../assets/audio/bg_music.mp3";
    this.bgaudio.loop=true;
     this.bgaudio.volume=0.5
      this.bgaudio.load();

    var u_settings=this.storage.getstoredata('user_settings');

    if(u_settings && u_settings.music)
    {
      setTimeout(() => {
        this.bgaudio.play();
      }, 3000);
      
    }
this.user_settings=u_settings;
    this.data.sock_msg.subscribe(x => this.sock_action(x))
    this.data.u_settings.subscribe(x => {

      this.user_settings=x
      console.log('start  playing');
      if(this.user_settings.music)
      {
        this.bgaudio.play();
       
      }
      else
      {
        this.bgaudio.pause();
      }

    })
   
    
    
    
   
  }

  

  sock_action(x:any)
{

  if(x.type=='crash' && x.command=='starting')
{ 
  this.crash_settings.stage = 'starting'

}

if(x.type=='crash' && x.command=='started')
{  
  this.flew_away=false
  this.crash_settings.stage = 'progress'
  this.crash_settings.start_time = new Date().getTime();  
  this.crash_settings.difference_time = x.difference
  this.refreshIntervalId = setInterval(() => {
    var cir_time = this.getTime();
    this.oddcounter =this.calcPayout(cir_time).toFixed(2)
  }, 0.1);
}

if(x.command=='crashed')
{
  if(this.user_settings.sound)
  {
      this.playAudio()
  }
  this.crash_settings.stage = 'crashed'
  console.log(this.crash_settings)
  clearInterval(this.refreshIntervalId);
  this.oddcounter=((x.number)/100).toFixed(2)
  
  this.flew_away=true

}

}
  callMethod(){
    console.log('Call Function Every Five Seconds.', new Date());
  }

    calcPayout(ms:any) {
    var gamePayout = Math.floor(100 * this.growthFunc(ms)) / 100;
    return gamePayout;
  }
  
   growthFunc(ms:any) {
    var r = 0.00006;
    return Math.pow(Math.E, r * ms);
  }
  
  getTime(){
    if(this.crash_settings.stage == 'progress') {
      var time = new Date().getTime() - this.crash_settings.start_time + this.crash_settings.difference_time;
      this.crash_settings.current_progress_time = time;
      return time;
    }
    if(this.crash_settings.stage == 'crashed') return this.crash_settings.current_progress_time;
    return 0;
  }

  

  playAudio(){
    let audio = new Audio();
    audio.src = "../assets/audio/fly_away.mp3";
    audio.load();
    audio.volume=0.9
    audio.play();
  }

  playbgAudio(){

 
    this.bgaudio.play();
  }
  
}
