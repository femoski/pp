import { Component } from '@angular/core';
import { SocketioService } from '../socketio.service';
import * as $ from "jquery";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
balance = 0.0
  constructor(private data: SocketioService)
  {
     
  }

  ngOnInit()
{ 
  this.data.sock_msg.subscribe(x => this.sock_action(x))
}
sock_action(x:any)
{

  if (x.type == 'first') {
    if(x.user)
    {
    
    this.animateValue(x.user.balance);
    }
  }
if(x.type=="balance")
{

this.animateValue(x.balance);
//this.balance=x.balance
//$('.act_balance').countToFloat(m.user.balance);
}


}


 animateValue(x:any) {

  var $this = $('#balance');

  var start = parseFloat($this.text());
		start = parseInt((start * 100).toString());

		var delta = parseInt((x * 100 - start).toString());
		
		var dur = Math.min(400, Math.round(Math.abs(delta) / 500 * 400));
		
		$({
			count: start
		}).animate({
			count: parseInt((x * 100).toString())
		}, {
			duration: dur,
			step: function(val) {
				var vts = parseInt(val.toString());
				
				$this.text((vts / 100).toFixed(2));
			}
		});
}

 getFormatAmountString(amount:any){
	return this.getFormatAmount(amount).toFixed(2);
}
 getFormatAmount(amount:any){
	return this.roundedToFixed(Number(amount), 2);
}
roundedToFixed(number:any, decimals:any){
  number = Number((parseFloat(number).toFixed(5)));
  
  var number_string = number.toString();
  var decimals_string = 0;
  
  if(number_string.split('.')[1] !== undefined) decimals_string = number_string.split('.')[1].length;
  
  while(decimals_string - decimals > 0) {
    number_string = number_string.slice(0, -1);
    
    decimals_string --;
  }
  
  return Number(number_string);
}
}
