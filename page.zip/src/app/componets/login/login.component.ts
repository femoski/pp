import { Component } from '@angular/core';
import {NgbActiveModal, NgbModal} from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms'
import { ApiService } from 'src/app/service/api.service';
import { Router } from '@angular/router';
import { StorageService } from 'src/app/service/storage.service';
import { SocketioService } from '../socketio.service';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  submitted = false
  error_msg:any
  found_error:boolean=false
  is_login:boolean=false


  private user_details = new BehaviorSubject<Array<any>>([]);
  public u_detail = this.user_details.asObservable()
  
  constructor(public activeModal: NgbModal,    private fb: FormBuilder,     private api: ApiService,
    private router: Router, private storage: StorageService, private sockdata: SocketioService
    )
  {

  }



  loginSection = this.fb.group({
    username: ['', Validators.required,],
    password: ['', Validators.required,],
   },
   
  );

  get registerFormControl() {
    return this.loginSection.controls;
  }

   callingFunction() {
    this.submitted=true
    this.found_error = false

    if(this.loginSection.valid)
    {

          var param= {username:this.loginSection.value['username'],
          password:this.loginSection.value['password']}
      
          this.api.post('login', param).subscribe((data: any) => {
             console.log('user info=>', data);
            if (data && data.status === 200) {
              //this.router.navigate(['']); 
                  this.storage.storearray('user_details',data.details)
              this.is_login = true

              this.sockdata.send_login_request(data.details)
              setTimeout(() => {
                this.activeModal.dismissAll('Reason')
              }, 2000);
            //  this.user_details.next(data.details)
            }
            else
            {
              this.found_error = true
              this.error_msg = data.errors
            }
          }, error => {
             console.log(error);
           });
       
    }

    


     }

}
