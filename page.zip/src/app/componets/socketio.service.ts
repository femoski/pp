import { Injectable } from '@angular/core';
import { io } from 'socket.io-client';
import { environment } from 'src/environments/environment';
import * as $ from "jquery";
import { BehaviorSubject, Subject } from 'rxjs';
import { StorageService } from '../service/storage.service';
@Injectable({
  providedIn: 'root'
})
export class SocketioService {

  private history = new BehaviorSubject<Array<any>>([]);
  public share = this.history.asObservable()
  private bb = new BehaviorSubject<Array<any>>([]);
  public bet_display_list = this.bb.asObservable()
  private ee = new BehaviorSubject<any>([]);
  public enginesession = this.ee.asObservable()
  public sock_msgg = new Subject<any>()
  public sock_msg = this.sock_msgg.asObservable()
  public u_data = new BehaviorSubject<Array<any>>([]);
  public u_settings = new BehaviorSubject<Array<any>>([]);


  socket:any;
  bet_list = new Array
  Engine = {
    gameState: 'CONNECTING', // either: STARTING, IN_PROGRESS,  ENDED, CONECTING
    startTime: new Date().getTime(),
    gameCrash: 0,
    elapsed: 0,
    crashTime: 0,
    graphPayout: 1
  }
  userdata = {
    session_id: 'Demo'
  }
  constructor(private storage: StorageService) {
      var udata=this.storage.getstoredata('user_details');
      if(udata)
      {
        this.userdata= udata
      }
   }
  

   update_settings(settings:any){
    this.u_settings.next(settings);
  }

  updateData(text:any){
    this.history.next(text);
  }

  send_sock_data(request:any){
    const ENCODING = 'utf-16le';
    let  str = JSON.stringify(request);
    var data = new TextEncoder().encode(str)
    this.socket.emit('request',{data});
    console.log(request)
  }


  send_login_request(user:any){
    var sec= {
      session: user.session_id,
      channel: 'en'
    }
    this.socket.emit('join', sec);
    this.u_data.next(user)
    console.log(user)
  }

  setupSocketConnection() {
    this.socket = io(environment.SOCKET_ENDPOINT, {
      auth: {
        token: "abc"
      }
    });

    var sec= {
      session: this.userdata.session_id,
      channel: 'en'
    }
    this.socket.emit('join', sec);
    const ENCODING = 'utf-16le';

    this.socket.on('b_message', (data: any) => {
      console.log(data)
      let str = new TextDecoder(ENCODING).decode(data.data),
      json = JSON.parse(str);
      this.onMessageSocket(json);
    });
    this.socket.on('message', (data: string) => {
      this.onMessageSocket(data);
    });

  }
  
  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
    }
  }



  onMessageSocket(m:any)
  {
 
    this.sock_msgg.next(m);

    if(m.history)
    {
     // console.log(m);
      this.crashGame_addHistory(m.number/100)
    }

 

   
    if(m.command=='crashed')
    {
     // this.bb.next(this.bet_list=[]);
    }

    if(m.command == 'reset') {
      this.bb.next(this.bet_list=[]);
    }

    if(m.command == 'bet_win') {
   this.crashGame_editBet(m.bet)
  }

  if(m.command == 'starting') {
    console.log(this.Engine.gameState = 'STARTING')
    this.ee.next(this.Engine)
  }
 
  if(m.command == 'get_bet_list') {
    console.log(this.Engine.gameState = 'BETLIST')
    this.ee.next(this.Engine)
  }

  }
  




   crashGame_addHistory(crash:any, isInitial = false){
    // var class_pick = (crash <= 1.79) ? 'pick-number-low' : (crash >= 2.00) ? 'pick-number-high' : 'pick-number-medium';
    let c = this.getCrashColor(crash);
 var div = `<div class="payout">
  <div class="bubble_animate multiplier_animate"><div class="multiplier_bubble" style="background:` + c.color + `">`+ this.roundedToFixed(crash, 2).toFixed(2) + `x</div>`

var div2=`<div class="payouts">
<div class="payout">
  <div>
    <div class="bubble-multiplier font-weight-bold" style="padding: 2px 11px; border-radius: 11px; color:` + c.color + `;" > `+ this.roundedToFixed(crash, 2).toFixed(2) + `x </div>
  </div>
</div>
</div>`
    $('.crash_history').prepend(div);
  //  while($('.crash_history').length > 20) $('.crash_history').last().remove();

    $('.crash_history_dropdown').prepend(div2);
  
    //while($('.crash_history_dropdown').length > 20) $('.crash_history_dropdown').last().remove();
console.log($('.crash_history_dropdown').length)
  }


  
  
  getCrashColor(val:any) {

    const CRASH_VAL_COLORS = [
      {min: 1.00, max: 2.00, bg: '#34b4ff', color: '#3e5bc2'},
      {min: 2.01, max: 10.00, bg: '#f70707', color: '#753ec2'},
      {min: 10.01, max: 9999999, bg: '#fff200', color: '#c017b4'},
    ];
    for(let i in CRASH_VAL_COLORS) {
      let c = CRASH_VAL_COLORS[i];
  
      if(val >= c.min && val <= c.max) {
        return c;
      }
    }
  
    return CRASH_VAL_COLORS[0];
  }


   crashGame_editBet(bet:any){

    //alert(bet.id)
    let c = this.getCrashColor(bet.cashout);
    var multiplyer=`<div>
    <div class="bubble_animate multiplier_animate"><div class="multiplier_bubble" style="background:` + c.color + `">`+ this.roundedToFixed(bet.cashout, 2).toFixed(2) + `x</div>
    </div>`
    $('#' + bet.id + ' .multiplier-block').html(multiplyer);
    $('#' + bet.id + ' .cash-out').text((bet.total_win*1).toFixed(2));
    $('#' + bet.id).addClass('celebrated');  
  }

  
   roundedToFixed(number:any, decimals:any){
    number = Number((parseFloat(number).toFixed(5)));
    
    var number_string = number.toString();
    var decimals_string = 0;
    
    if(number_string.split('.')[1] !== undefined) decimals_string = number_string.split('.')[1].length;
    
    while(decimals_string - decimals > 0) {
      number_string = number_string.slice(0, -1);
      
      decimals_string --;
    }
    
    return Number(number_string);
  }
  
}