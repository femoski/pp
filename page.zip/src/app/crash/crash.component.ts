import { Component, ElementRef, ViewChild } from "@angular/core";
import { CrashService } from "../service/crash.service";

@Component({
  selector: "app-crash",
  templateUrl: "./crash.component.html",
  styleUrls: ["./crash.component.scss"],
})
export class CrashComponent {

  constructor(public crash: CrashService)
  {

  }
}
