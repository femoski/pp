import { Component, ViewChild } from '@angular/core';
import { SocketioService } from '../componets/socketio.service';
import * as $ from "jquery";
import {ElementRef,Renderer2} from '@angular/core';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-balance',
  templateUrl: './balance.component.html',
  styleUrls: ['./balance.component.scss']
})
export class BalanceComponent {
  balancen = 0.0
  @ViewChild("balance") balance!: ElementRef;

  constructor(private data: SocketioService,private user: UserService)
  {
     
  }


  ngOnInit()
  { 
console.log(this.user.balance)

  }
  public ngAfterViewInit() {
    this.animateValue(this.user.balance);
  }


  
   animateValue(x:any) {
  
    var $this =  this.balance.nativeElement

    var start = parseFloat($this.textContent);
      start = parseInt((start * 100).toString());
  
      var delta = parseInt((x * 100 - start).toString());
      
      var dur = Math.min(400, Math.round(Math.abs(delta) / 500 * 400));
      
      $({
        count: start
      }).animate({
        count: parseInt((x * 100).toString())
      }, {
        duration: dur,
        step: function(val) {
          var vts = parseInt(val.toString());
          
          $this.textContent=(vts / 100).toFixed(2);
        }
      });
  }
  
   getFormatAmountString(amount:any){
    return this.getFormatAmount(amount).toFixed(2);
  }
   getFormatAmount(amount:any){
    return this.roundedToFixed(Number(amount), 2);
  }
  roundedToFixed(number:any, decimals:any){
    number = Number((parseFloat(number).toFixed(5)));
    
    var number_string = number.toString();
    var decimals_string = 0;
    
    if(number_string.split('.')[1] !== undefined) decimals_string = number_string.split('.')[1].length;
    
    while(decimals_string - decimals > 0) {
      number_string = number_string.slice(0, -1);
      
      decimals_string --;
    }
    
    return Number(number_string);
  }
  
}
