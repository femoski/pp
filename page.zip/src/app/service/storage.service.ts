
import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class StorageService {


  getstoredata(value:any)
  {
var jsondata = JSON.parse(localStorage.getItem(value)!);
return jsondata
  }
  
  storearray(name:any,data:any)
  {
   var jsondata =   localStorage.setItem(name, JSON.stringify(data));
return jsondata
  }
  

}