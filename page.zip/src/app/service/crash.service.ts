import { ElementRef, Injectable, Input, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { SocketioService } from '../componets/socketio.service';
import * as $ from "jquery";
import { StorageService } from './storage.service';

@Injectable({
  providedIn: 'root'
})
export class CrashService {
  refreshIntervalId: any;
  bgaudio = new Audio();
  oddcounter = "Connecting";
  flew_away: boolean = false;
  user_settings: any;
  crash_settings = {
    start_time: new Date().getTime(),
    current_progress_time: 0,
    difference_time: 0,
    stage: "starting",
  };

  stake_1: any = "10.00";
  stake_2: any = "10.00";
  
  autobet_1_value: any = "2.00";
  autobet_2_value: any = "2.00";

  next_round_list = new Array();
  btn_stage = "place_bet_stage";
  btn_stage_1 = "place_bet_stage";
  cashout_amt_1 = "0.00";
  cashout_amt_2 = "0.00";
  awaiting = true;
  autobet_1 = false;
  auto_cashout_1 = false;
  auto_cashout_2 = false;

  stake_12: any;
  stake_button_2: boolean = true;
  value1: any;
  userdata:any
  usersettings:any

  bet_list_players: any;
  bet_list = new Array();
  crash_history_list=new Array;
  divMessages: any = '';

  constructor(
    private data: SocketioService,
    private storage: StorageService,
    private toastr: ToastrService,

  ) {

    this.usersettings=
    {
      animation:true,
      music:true,
       sound:true
    }
    var udata=this.storage.getstoredata('user_details');
    var u_settings=this.storage.getstoredata('user_settings');

    if(u_settings)
    {
      this.usersettings=u_settings;
    }


    this.bgaudio.src = "../assets/audio/bg_music.mp3";
    this.bgaudio.loop = true;
    this.bgaudio.volume = 0.5;
    this.bgaudio.load();

    var u_settings = this.storage.getstoredata("user_settings");

    if (u_settings && u_settings.music) {
      setTimeout(() => {
        this.bgaudio.play();
      }, 3000);
    }
    this.user_settings = u_settings;
    this.data.sock_msg.subscribe((x) => this.sock_action(x));
    this.data.u_settings.subscribe((x) => {
      this.user_settings = x;
      console.log("start  playing");
      if (this.user_settings.music) {
        this.bgaudio.play();
      } else {
        this.bgaudio.pause();
      }
    });
  
  

  }

  ngOnDestroy(): void {
    // never forget to add this line.
    // this.data.sock_msg.unsubscribe()
    
  }




  animateValue(x:any) {

    var $this = $('#balance');
  
    var start = parseFloat($this.text());
      start = parseInt((start * 100).toString());
  
      var delta = parseInt((x * 100 - start).toString());
      
      var dur = Math.min(400, Math.round(Math.abs(delta) / 500 * 400));
      
      $({
        count: start
      }).animate({
        count: parseInt((x * 100).toString())
      }, {
        duration: dur,
        step: function(val) {
          var vts = parseInt(val.toString());
          
          $this.text((vts / 100).toFixed(2));
        }
      });
  }

  
  sock_action(x: any) {

    if (x.type == 'error') {
      this.error_msg(x.error)
    }


    if (x.type == 'first') {
      this.crash_history_list=x.crash.history;

         if(x.user)
        {
        this.animateValue(x.user.balance);
        }
  
    }

    if (x.type == "first") {
      
      x.crash.bets_all.forEach((crash: any, i: any) => {
        var list = {
          id: x.crash.bets_all[i].id,
          amount: x.crash.bets_all[i].amount,
          name: x.crash.bets_all[i].user.name,
          avatar_intials: x.crash.bets_all[i].user.avatar_intials,
          avatar: x.crash.bets_all[i].user.avatar,
        };

        this.bet_list.push(list);
      });
      this.bet_list_players = this.bet_list.sort(
        (a: any, b: any) => a.amount - b.amount
      );
      console.log(this.bet_list_players);

      setTimeout(() => {
        x.crash.bets_win.forEach((crash: any, i: any) => {
          this.data.crashGame_editBet(crash);
          console.log(crash);
        });
      }, 100);
    }

    if (x.command == "bet") {
      var new_bet = {
        id: x.bet.id,
        amount: x.bet.amount,
        name: x.bet.user.name,
        avatar_intials: x.bet.user.avatar_intials,
        avatar: x.bet.user.avatar,
      };

      this.bet_list.push(new_bet);
      this.bet_list_players = this.bet_list.sort(
        (a: any, b: any) => a.amount - b.amount
      );
    }

    if (x.command == "reset") {
      this.bet_list = [];
      this.bet_list_players = this.bet_list = [];
    }


    if (x.type == "crash" && x.command == "get_bet_list" || x.command == "starting") {
      console.log;
      console.log("we visited");
      
      this.next_round_list.forEach((crash: any, i: any) => {

        
        setTimeout(() => {

          var sock_data = {
            type: "crash",
            command: "bet",
            amount: crash.amount,
            auto: crash.auto_cashout,
            btn: crash.button,
          };
          this.data.send_sock_data(sock_data);
          delete this.next_round_list[i];

        }, i * 500);
      });

      this.next_round_list = [];
    }

    if (x.type == "crash" && x.command == "starting") {
      this.crash_settings.stage = "starting";
    }

    if (x.type == "crash" && x.command == "started") {
      this.flew_away = false;
      this.crash_settings.stage = "progress";
      this.crash_settings.start_time = new Date().getTime();
      this.crash_settings.difference_time = x.difference;
      this.refreshIntervalId = setInterval(() => {
        var cir_time = this.getTime();
        this.oddcounter = this.calcPayout(cir_time).toFixed(2);
      }, 0.1);
    }

    if (x.command == "crashed") {

//       var appendElement = '<li>ns --- </li>' ;
// this.divMessages = this.divMessages + appendElement;

      if (this.user_settings.sound) {
        this.playAudio();
      }
      this.crash_settings.stage = "crashed";
      console.log(this.crash_settings);
      clearInterval(this.refreshIntervalId);
      this.oddcounter = (x.number / 100).toFixed(2);

      this.flew_away = true;
    }

    console.log(x);

    if (x.command == "starting") {
      this.awaiting = false;
    }

    if (x.command == "started") {
      this.awaiting = true;
    }

    if (x.command == "cashout") {
      if (x.btn == "btn_1") {
        this.cashout_amt_1 = x.amount.toFixed(2);
        this.btn_stage_1 = "cashout_bet_stage";
      }

      if (x.btn == "btn_2") {
        this.cashout_amt_2 = x.amount.toFixed(2);
        this.btn_stage = "cashout_bet_stage";
      }
    }

    if (x.command == "cashed_out") {
      if (x.btn == "btn_2") {
        this.btn_stage = "place_bet_stage";
      }

      if (x.btn == "btn_1") {
        this.btn_stage_1 = "place_bet_stage";

        if (this.autobet_1) {
          this.place_bet(x.btn);
        }
      }

      var cashohtml =
        `<div class="d-flex">
        <div class="multiplier ">
          <div class="label"> You have cashed out! </div>
          <div class="value"> ` +
        (x.point / 100).toFixed(2) +
        `x </div>
        </div>
        <div class="win celebrated">
          <div class="label no-wrap ">
            <span>Won</span>
            <span class="currency">, NGN</span>
          </div>
          <div class="value">
            <span class="">` +
        x.amount.toFixed(2) +
        `</span>
          </div>
        </div>
      </div>`;
      this.toastr.success(cashohtml, "", {
        timeOut: 7000,
        toastClass: "alert-win",
      });
      this.playAudio();
    }

    if (x.command == "crashed") {
      if (this.btn_stage == "cashout_bet_stage") {
        this.btn_stage = "place_bet_stage";
      }
      if (this.btn_stage_1 == "cashout_bet_stage") {
        this.btn_stage_1 = "place_bet_stage";
        if (this.autobet_1) {
          this.place_bet("btn_1");
        }
      }
    }
  }
  callMethod() {
    console.log("Call Function Every Five Seconds.", new Date());
  }

  calcPayout(ms: any) {
    var gamePayout = Math.floor(100 * this.growthFunc(ms)) / 100;
    return gamePayout;
  }

  growthFunc(ms: any) {
    var r = 0.00006;
    return Math.pow(Math.E, r * ms);
  }

  getTime() {
    if (this.crash_settings.stage == "progress") {
      var time =
        new Date().getTime() -
        this.crash_settings.start_time +
        this.crash_settings.difference_time;
      this.crash_settings.current_progress_time = time;
      return time;
    }
    if (this.crash_settings.stage == "crashed")
      return this.crash_settings.current_progress_time;
    return 0;
  }

  playAudio() {
    let audio = new Audio();
    audio.src = "../assets/audio/fly_away.mp3";
    audio.load();
    audio.volume = 0.9;
    audio.play();
  }

  playbgAudio() {
    this.bgaudio.play();
  }

  cashout_bet(button: any) {
    var cashout_data = {
      type: "crash",
      command: "cashout",
      btn: button,
    };
    this.data.send_sock_data(cashout_data);
  }

  plus(val: any, type: any) {
    if (type == "btn_1") {
      var value = val * 1 + 30;
      this.stake_1 = value.toFixed(2);
      console.log(this.roundedToFixed(value, 2).toFixed(2));
      if (this.stake_1 > 5000) {
        this.stake_1 = "5000.00";
      }
    }

    if (type == "btn_2") {
      var value = val * 1 + 30;
      this.stake_2 = value.toFixed(2);
      if (this.stake_2 > 5000) {
        this.stake_2 = "5000.00";
      }
    }
  }

  minus(val: any, type: any) {
    if (type == "btn_1") {
      var value = val * 1 - 30;
      this.stake_1 = value.toFixed(2);
      if (this.stake_1 < 10) {
        this.stake_1 = "10.00";
      }
    }

    if (type == "btn_2") {
      var value = val * 1 - 30;
      this.stake_2 = value.toFixed(2);
      if (this.stake_2 < 10) {
        this.stake_2 = "10.00";
      }
    }
  }

  roundedToFixed(number: any, decimals: any) {
    number = Number(parseFloat(number).toFixed(5));

    var number_string = number.toString();
    var decimals_string = 0;

    if (number_string.split(".")[1] !== undefined)
      decimals_string = number_string.split(".")[1].length;

    while (decimals_string - decimals > 0) {
      number_string = number_string.slice(0, -1);

      decimals_string--;
    }

    return Number(number_string);
  }

  inputchange(value: any, type: any) {
    if ((type == "btn_1")) {
      this.stake_1 = (value * 1).toFixed(2);

      if (this.stake_1 < 10) {
        this.stake_1 = "10.00";
      }
    }

    if ((type == "btn_2")) {
      this.stake_2 = (value * 1).toFixed(2);

      if (this.stake_2 < 10) {
        this.stake_2 = "10.00";
      }
    }
  }

  place_bet(button: any) {
    var autocash = 0;
    let pusheditems = {};



    if(!this.awaiting)
    {
      if (button == "btn_2") {
        if (this.auto_cashout_2) {
          autocash = this.autobet_2_value;
        }
        pusheditems = {
          amount: this.stake_2,
          auto_cashout: autocash * 100,
          button: button,
        };
        var sock_data = {
          type: "crash",
          command: "bet",
          amount: this.stake_2,
          auto: autocash * 100,
          btn: button
        };
        this.data.send_sock_data(sock_data);

        this.btn_stage = "cancel_bet_stage";
      } else {
        var autocash = 0;
        if (this.auto_cashout_1) {
          autocash = this.autobet_1_value;
        }
        var sock_data = {
          type: "crash",
          command: "bet",
          amount: this.stake_1,
          auto: autocash * 100,
          btn: button
        };
        this.data.send_sock_data(sock_data);
        this.btn_stage_1 = "cancel_bet_stage";
      }

      console.log('not waiting');
    }
    else
    {

    let pusheditems = {};
    if (button == "btn_2") {
      if (this.auto_cashout_2) {
        autocash = this.autobet_2_value;
      }
      pusheditems = {
        amount: this.stake_2,
        auto_cashout: autocash * 100,
        button: button,
      };
      this.btn_stage = "cancel_bet_stage";
    } else {
      var autocash = 0;
      if (this.auto_cashout_1) {
        autocash = this.autobet_1_value;
      }
      pusheditems = {
        amount: this.stake_1,
        auto_cashout: autocash * 100,
        button: button,
      };
      this.btn_stage_1 = "cancel_bet_stage";
    }

    this.next_round_list.push(pusheditems);
    console.log(this.next_round_list);

    //this.RemoveElementFromArray(this.stake_1)
  }
  }

  cancel_stake(button: any) {
    this.RemoveElementFromArray(button);

    if (button == "btn_2") {
      this.btn_stage = "place_bet_stage";
    }
    if (button == "btn_1") {
      this.btn_stage_1 = "place_bet_stage";
      this.autobet_1 = false;
    }
  }
  RemoveElementFromArray(element: any) {
    this.next_round_list.forEach((value: any, index: any) => {
      if (value.button == element) this.next_round_list.splice(index, 1);
    });
  }

  check_autocashout(value: any, type: any) {
    console.log(value);

    if ((type == "btn_1")) {

      this.autobet_1_value = (value * 1).toFixed(2);

      if (value < 1.01) {
        this.autobet_1_value =(2.00).toFixed(2);
      }

      if (value > 100) {
        console.log('greater')
        this.autobet_1_value = (100.00).toFixed(2);
      }

    }


    if ((type == "btn_2")) {
      this.autobet_2_value = (value * 1).toFixed(2);

      if (value < 1.01) {
        this.autobet_2_value = (2.00).toFixed(2);
      }

      if (value > 100) {
        console.log('greater')
        this.autobet_2_value = (100.00).toFixed(2);
      }

    }
  }

  autobet_control(button: any) {
    this.autobet_1 = !this.autobet_1;
    if (this.autobet_1) {
      this.place_bet("btn_1");
    } else {
      this.cancel_stake("btn_1");
    }
  }

  game_audio_settings(type:any){
    console.log('it offf')
       if(type=="animation")
       {
         this.usersettings.animation =  !this.usersettings.animation
       }
       if(type=="music")
       {
         this.usersettings.music =  !this.usersettings.music
       }
        if(type=="sound")
       {
         this.usersettings.sound =  !this.usersettings.sound
       }
       this.storage.storearray('user_settings', this.usersettings)
    this.data.update_settings(this.usersettings)
     }

     getCrashColor(val:any) {

  const CRASH_VAL_COLORS = [
    {min: 1.00, max: 2.00, bg: '#34b4ff', color: '#3e5bc2'},
    {min: 2.01, max: 10.00, bg: '#f70707', color: '#753ec2'},
    {min: 10.01, max: 9999999, bg: '#fff200', color: '#c017b4'},
  ];
  for(let i in CRASH_VAL_COLORS) {
    let c = CRASH_VAL_COLORS[i];

    if(val >= c.min && val <= c.max) {
      return c.color;
    }
  }

  return CRASH_VAL_COLORS[0];
}

 colorize(str:any) {
  for (var i = 0, hash = 0; i < str.length; hash = str.charCodeAt(i++) + ((hash << 5) - hash));
  var color = Math.floor(Math.abs((Math.sin(hash) * 10000) % 1 * 16777216)).toString(16);
  return '#' + Array(6 - color.length + 1).join('0') + color;
}

error_msg(msg:any)
{
  var cashohtml =
  `<div class="d-flex">
 `+msg+`
</div>`;
this.toastr.success(cashohtml, "", {
  timeOut: 8000,
  toastClass: "alert-error",
});

}


}
