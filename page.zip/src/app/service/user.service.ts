import { Injectable } from '@angular/core';
import { SocketioService } from '../componets/socketio.service';
import { StorageService } from './storage.service';
import * as $ from "jquery";

@Injectable({
  providedIn: 'root'
})
export class UserService {
user_balance:any
islogin:boolean =false;

  constructor(private storage: StorageService,private socketinfo:SocketioService) {
   
    var udata=this.storage.getstoredata('user_details');
    this.socketinfo.u_data.subscribe(x => this.update(x))

    if(udata)
    {
      this.islogin=true
    }

    this.socketinfo.sock_msg.subscribe(m => {
      if (m.type == 'first') {
    if(m.user)
    { 
    this.animateValue(m.user.balance);
    this.setbalance(m.user.balance)
    }
  }

  if(m.type=="balance")
      {
      this.animateValue(m.balance);
      this.setbalance(m.balance)
      }
})

   }



  update(x:any)
  {
    if(x.length!=0)
    { 
      this.islogin=true
    }
    else{
      this.islogin=false
    }
   
  }

  get islogin_check()
  {
    return this.islogin  
  }



  setbalance(balance:any)
  {
    console.log('got'+balance)
    this.user_balance=balance
  }  

  get balance()
  {
    return this.user_balance
  }





 animateValue(x:any) {

  var $this = $('#balance');

  var start = parseFloat($this.text());
		start = parseInt((start * 100).toString());

		var delta = parseInt((x * 100 - start).toString());
		
		var dur = Math.min(400, Math.round(Math.abs(delta) / 500 * 400));
		
		$({
			count: start
		}).animate({
			count: parseInt((x * 100).toString())
		}, {
			duration: dur,
			step: function(val) {
				var vts = parseInt(val.toString());
				
				$this.text((vts / 100).toFixed(2));
			}
		});
}

 getFormatAmountString(amount:any){
	return this.getFormatAmount(amount).toFixed(2);
}
 getFormatAmount(amount:any){
	return this.roundedToFixed(Number(amount), 2);
}
roundedToFixed(number:any, decimals:any){
  number = Number((parseFloat(number).toFixed(5)));
  
  var number_string = number.toString();
  var decimals_string = 0;
  
  if(number_string.split('.')[1] !== undefined) decimals_string = number_string.split('.')[1].length;
  
  while(decimals_string - decimals > 0) {
    number_string = number_string.slice(0, -1);
    
    decimals_string --;
  }
  
  return Number(number_string);
}


}
