import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
 import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
 import {ScrollingModule} from '@angular/cdk/scrolling'
import { SocketioService } from './componets/socketio.service';
 import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './componets/login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { CrashComponent } from './crash/crash.component';
import { LimitComponent } from './componets/limit/limit.component';
import { KeyboardComponent } from './keyboard/keyboard.component';
import { KeyboardService } from './keyboard.service';
import { OskInputDirective } from './osk-input.directive';
import { KeyboardKeyDirective } from './keyboard-key.directive';
import { BalanceComponent } from './balance/balance.component';
import { HomeComponent } from './home/home.component';
import { SplashscreenComponent } from './splashscreen/splashscreen.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    CrashComponent,
    LimitComponent,
    KeyboardComponent, OskInputDirective, KeyboardKeyDirective, BalanceComponent, HomeComponent, SplashscreenComponent 
  ],
  imports: [
    BrowserModule,
    NgbModule,
    ScrollingModule,
    BrowserAnimationsModule,
    FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        
    ToastrModule.forRoot({
      positionClass :'toast-top-center',
      // closeButton: true,
      enableHtml:true,
    }),
    AppRoutingModule
  ],
  providers: [SocketioService,KeyboardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
